<?php
declare(strict_types=1);
/*
  _____ _             _    _____  ______
 / ____| |           | |  |  __ \|  ____|
| (___ | |_ ___   ___| | _| |__) | |__
 \___ \| __/ _ \ / __| |/ /  ___/|  __|
 ____) | || (_) | (__|   <| |    | |____
|_____/ \__\___/ \___|_|\_\_|    |______|
                                         */
namespace StockPE\MCBE;

//pmmp libs!
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\server\ServerCommandEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\TextFormat as C;
use pocketmine\command\{Command, CommandSender, defaults\VanillaCommand};
use pocketmine\entity\Entity;
use pocketmine\utils\Config;
use pocketmine\level\Position;
use pocketmine\command\ConsoleCommandSender;

class Main extends PluginBase implements Listener {

    /*public static $LeVEls = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10',
                                '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
                                '21', '22', '23', '24', '25', '26', '27', '28', '29', '30',
                                '31', '32', '33', '34', '35', '36', '37', '38', '39', '40',
                                '41', '42', '43', '44', '45', '46', '47', '48', '49', '50'];*/
    public $economyapi;
    public $formapi;
    public $pureperms;
    public $price;

    public function onEnable(): void
      {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->economyapi = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        $this->formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $this->pureperms = $this->getServer()->getPluginManager()->getPlugin("PureChat");
        foreach([$this->economyapi, $this->formapi, $this->pureperms] as $chEcKEr)
          {
            if($chEcKEr === null || $chEcKEr->isDisabled())
             {
               return;
             } else
                 {
                   //plugin setup!
                   @mkdir($this->getDataFolder());
                   $this->saveDefaultConfig();
                   $this->saveResource("editable.yml");
                   $this->saveResource("not-editable.yml");
                   $this->cfg = new Config($this->getDataFolder() . "editable.yml", Config::YAML);
                   $this->rst = new Config($this->getDataFolder() . "not-editable.yml", Config::YAML);
                   $this->getServer()->getLogger()->info("Plugin LevelUP by 7Wdev!!!!");
                 }
          }
      }

    public function onJoin(PlayerJoinEvent $e)
      {
        $p = $e->getPlayer();
        if(!$this->rst->exists(strtolower($p->getName())))
         {
           $this->addPlayer($p);
         }
        $this->setNamedTag($p);
      }



    /******************** LEVEL COMMANDS ********************/
    public function onCommand(CommandSender $sender, Command $command, $label, array $args) : bool
      {
        switch(strtolower($command->getName()))
          {
            case "levelup":
            $this->sendLevelUpFormUi($sender);
            //$this->initializeLevel($sender);
            break;

            case "addexp":
            if(isset($args[0]) && isset($args[1]) && is_numeric($args[1]))
             {
               $this->addExp($args[0], $args[1]);
               return true;
               break;
             }

            case "reduceexp":
            if(isset($args[0]) && is_numeric($args[0]) && isset($args[1]))
             {
               $this->reduceExp($args[0], $args[1]);
               return true;
               break;
             }
          }
        return true;
      }



    /******************** LEVEL API ********************/
    public function initializeLevel($player)
      {
        $exp = $this->getExp($player);
        $expn = $this->getExpNeededTLU($player);
        if($this->getLevel($player) == 50)
         {
           $player->sendMessage(C::ITALIC. C::RED. "You have already reached the max level, silly!");
         }
        if($this->getLevel($player) < 50)
         {
           $this->price = $this->getLevel($player) * $this->getLevel($player) * (256.50);
           if($this->economyapi::getInstance()->myMoney($player) >= $this->price)
            {
              $this->economyapi::getInstance()->reduceMoney($player->getName(), $this->price);
              $this->levelUp($player);
              $this->reduceExp($player, $expn);
              $this->setNamedTag($player);
              $this->addExpNeededTLU($player, $expn * 1);
              $player->sendMessage(C::ITALIC. "Successfully leveled up to ". $this->getLevel($player). "!");
            } else
                {
                  $player->sendMessage(C::ITALIC. C::RED. "You don't have enough money to level up!");
                }
         } else
             {
               $player->sendMessage(C::ITALIC. C::RED. "You have already reached the max level, silly!");
             }
      }

    public function levelUp($player)
      {
        $this->rst->setNested(strtolower($player->getName()).".lvl", $this->rst->getAll()[strtolower($player->getName())]["lvl"] + 1);
        $this->rst->save();
        $this->setNamedTag($player);
        $this->getServer()->broadcastMessage(C::ITALIC. $player->getName(). " is now level ". $this->getLevel($player). "!");
      }

    public function setNamedTag($player)
      {
        $player->setDisplayName(C::BOLD . C::DARK_GRAY. "[". C::YELLOW . "" . $this->getLevel($player) . C::DARK_GRAY. "] ". C::RESET. $player->getName());
        $player->setNameTag(C::RESET. $this->pureperms->getNametag($player));
        $player->save();
      }

    public function reduceExp($player, $exp)
      {
        $this->rst->setNested(strtolower($player->getName()).".exp", $this->rst->getAll()[strtolower($player->getName())]["exp"] - $exp);
        $this->rst->save();
      }

    public function addExp($player, $exp)
      {
        $this->rst->setNested(strtolower($player).".exp", $this->rst->getAll()[strtolower($player)]["exp"] + $exp);
        $this->rst->save();
      }

    public function addExpNeededTLU($player, $exp)
      {
        $this->rst->setNested(strtolower($player->getName()).".expneededtlu", $this->rst->getAll()[strtolower($player->getName())]["expneededtlu"] + $exp);
        $this->rst->save();
      }

    public function getExp($player)
      {
        return $this->rst->getAll()[strtolower($player->getName())]["exp"];
      }

    public function getLevel($player)
      {
        return $this->rst->getAll()[strtolower($player->getName())]["lvl"];
      }

    public function getExpNeededTLU($player)
      {
        return $this->rst->getAll()[strtolower($player->getName())]["expneededtlu"];
      }

    public function addPlayer($player)
      {
        $this->rst->setNested(strtolower($player->getName()).".lvl", "1");
        $this->rst->setNested(strtolower($player->getName()).".exp", "0");
        $this->rst->setNested(strtolower($player->getName()).".expneededtlu", "250");
        $this->rst->save();
      }



    /******************** LEVEL UI ********************/
    public function sendLevelUpFormUi($player)
      {
        $form = $formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $nextlevel = $this->getLevel($player) + 1;
        $this->price = $this->getLevel($player) * $this->getLevel($player) * (256.50);
        $form = $formapi->createSimpleForm(function(Player $player, $data)
          {
            $result = $data;
            if($result === null) return;
            switch($result)
              {
                case 0:
                $this->initializeLevel($player);
                if($this->cfg->get("rewards") === true)
                 {
                   switch($this->getLevel($player))
                     {
                       case 1:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl1")));
                       break;

                       case 2:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl2")));
                       break;

                       case 3:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl3")));
                       break;

                       case 4:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl4")));
                       break;

                       case 5:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl5")));
                       break;

                       case 6:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl6")));
                       break;

                       case 7:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl7")));
                       break;

                       case 8:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl8")));
                       break;

                       case 9:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl9")));
                       break;

                       case 10:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl10")));
                       break;

                       case 11:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl11")));
                       break;

                       case 12:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl12")));
                       break;

                       case 13:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl13")));
                       break;

                       case 14:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl14")));
                       break;

                       case 15:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl15")));
                       break;

                       case 16:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl16")));
                       break;

                       case 17:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl17")));
                       break;

                       case 18:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl18")));
                       break;

                       case 19:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl19")));
                       break;

                       case 20:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl20")));
                       break;

                       case 21:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl21")));
                       break;

                       case 22:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl22")));
                       break;

                       case 23:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl23")));
                       break;

                       case 24:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl24")));
                       break;

                       case 25:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl25")));
                       break;

                       case 26:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl26")));
                       break;

                       case 27:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl27")));
                       break;

                       case 28:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl28")));
                       break;

                       case 29:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl29")));
                       break;

                       case 30:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl30")));
                       break;

                       case 31:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl31")));
                       break;

                       case 32:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl32")));
                       break;

                       case 33:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl33")));
                       break;

                       case 34:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl34")));
                       break;

                       case 35:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl35")));
                       break;

                       case 36:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl36")));
                       break;

                       case 37:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl37")));
                       break;

                       case 38:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl38")));
                       break;

                       case 39:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl39")));
                       break;

                       case 40:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl40")));
                       break;

                       case 41:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl41")));
                       break;

                       case 42:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl42")));
                       break;

                       case 43:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl43")));
                       break;

                       case 44:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl44")));
                       break;

                       case 45:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl45")));
                       break;

                       case 46:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl46")));
                       break;

                       case 47:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl47")));
                       break;

                       case 48:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl48")));
                       break;

                       case 49:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl49")));
                       break;

                       case 50:
                       $this->getServer()->dispatchCommand($player, str_replace("{player}", $player->getName(), $this->cfg->get("lvl50")));
                       break;
                     }
                 } else
                     {
                     //dont give reward !
                     }
                return;

                case 1:
                return;
              }
          });
        $form->setTitle("LevelUP-UI");
        $form->setContent("\nDo you want to upgrade your level for better experience? \n\n Upgrading for level " . C::RED . C::BOLD . $nextlevel . C::RESET . " costs " . C::BOLD . C::GOLD . $this->price . "$");
        $form->addButton("UPGRADE");
        $form->addButton("BACK");
        $form->sendToPlayer($player);
      }
}