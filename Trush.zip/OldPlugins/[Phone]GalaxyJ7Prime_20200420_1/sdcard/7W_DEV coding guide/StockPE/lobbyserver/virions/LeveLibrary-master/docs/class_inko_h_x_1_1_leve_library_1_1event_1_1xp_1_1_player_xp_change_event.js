var class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_xp_change_event =
[
    [ "__construct", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_xp_change_event.html#ab15fadcb54166fbde13eb08b7df9fc09", null ],
    [ "getNewXp", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_xp_change_event.html#a90a32024001704c29bc4a898ca5f1cf8", null ],
    [ "getOldXp", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_xp_change_event.html#a3c35787799be6c1fc55ef3b608cdaee2", null ],
    [ "setNewXp", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_xp_change_event.html#a5f50aec876412a84286e87ecb02fbbc6", null ]
];