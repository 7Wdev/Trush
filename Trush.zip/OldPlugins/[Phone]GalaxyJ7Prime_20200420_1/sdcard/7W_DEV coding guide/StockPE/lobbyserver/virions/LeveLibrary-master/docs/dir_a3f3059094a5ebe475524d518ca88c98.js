var dir_a3f3059094a5ebe475524d518ca88c98 =
[
    [ "level", "dir_7b83899dd80fc84cf6c36bcd1c131b6c.html", "dir_7b83899dd80fc84cf6c36bcd1c131b6c" ],
    [ "xp", "dir_1ad540fb78624f92bdad7e483cded527.html", "dir_1ad540fb78624f92bdad7e483cded527" ]
];