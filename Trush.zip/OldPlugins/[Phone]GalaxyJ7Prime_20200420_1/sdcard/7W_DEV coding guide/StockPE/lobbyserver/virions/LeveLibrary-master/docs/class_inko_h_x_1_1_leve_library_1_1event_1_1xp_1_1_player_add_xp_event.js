var class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_add_xp_event =
[
    [ "__construct", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_add_xp_event.html#a272d453bf0c2a7ce2c056f5b06c0cb68", null ],
    [ "getXp", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_add_xp_event.html#aac0d2a9d3dfa2179cc43bf4a1348cd87", null ],
    [ "setXp", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_add_xp_event.html#a9b7610434ed3be53bdd478aace0aed77", null ]
];