var namespace_inko_h_x_1_1_leve_library_1_1event =
[
    [ "level", "namespace_inko_h_x_1_1_leve_library_1_1event_1_1level.html", "namespace_inko_h_x_1_1_leve_library_1_1event_1_1level" ],
    [ "xp", "namespace_inko_h_x_1_1_leve_library_1_1event_1_1xp.html", "namespace_inko_h_x_1_1_leve_library_1_1event_1_1xp" ]
];