var class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_max_xp_change_event =
[
    [ "__construct", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_max_xp_change_event.html#abb704521c4765c670d39e24cb38ebe55", null ],
    [ "getNewMax", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_max_xp_change_event.html#a821b2cf63f57739f09d7cfe6ff93f411", null ],
    [ "getOldMax", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_max_xp_change_event.html#a341e0bfaf313ea3206b8797914b980c9", null ],
    [ "setNewMax", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_max_xp_change_event.html#ab62692add8b5e862e0029a4736cfe87b", null ]
];