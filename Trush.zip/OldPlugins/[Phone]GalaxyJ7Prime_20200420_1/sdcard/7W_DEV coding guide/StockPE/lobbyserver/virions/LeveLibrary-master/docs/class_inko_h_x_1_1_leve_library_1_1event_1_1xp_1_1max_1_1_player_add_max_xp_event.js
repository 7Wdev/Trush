var class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_add_max_xp_event =
[
    [ "__construct", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_add_max_xp_event.html#ae660aaedbde1ed64393a835b6253cab3", null ],
    [ "getMax", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_add_max_xp_event.html#abeb2912350107c52d5320b68beaceae7", null ],
    [ "setMax", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_add_max_xp_event.html#a60f63b943d11da8ea2bf9562f01392b6", null ]
];