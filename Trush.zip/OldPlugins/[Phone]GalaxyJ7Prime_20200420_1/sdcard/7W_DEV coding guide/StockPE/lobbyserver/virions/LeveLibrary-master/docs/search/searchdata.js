var indexSectionsWithContent =
{
  0: "_adegilnprs",
  1: "dlp",
  2: "i",
  3: "dlpr",
  4: "_aegins",
  5: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "pages"
};

var indexSectionLabels =
{
  0: "全て",
  1: "データ構造",
  2: "名前空間",
  3: "ファイル",
  4: "関数",
  5: "ページ"
};

