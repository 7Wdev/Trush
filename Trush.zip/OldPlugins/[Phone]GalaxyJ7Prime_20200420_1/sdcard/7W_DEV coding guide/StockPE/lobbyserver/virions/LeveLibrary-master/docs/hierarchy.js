var hierarchy =
[
    [ "DataFile", "class_inko_h_x_1_1_leve_library_1_1_data_file.html", null ],
    [ "LevelAPI", "class_inko_h_x_1_1_leve_library_1_1_level_a_p_i.html", null ],
    [ "Cancellable", null, [
      [ "PlayerLevelChangeEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1level_1_1_player_level_change_event.html", null ],
      [ "PlayerLevelUpEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1level_1_1_player_level_up_event.html", null ],
      [ "PlayerAddMaxXpEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_add_max_xp_event.html", null ],
      [ "PlayerMaxXpChangeEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_max_xp_change_event.html", null ],
      [ "PlayerAddXpEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_add_xp_event.html", null ],
      [ "PlayerXpChangeEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_xp_change_event.html", null ]
    ] ],
    [ "PlayerEvent", null, [
      [ "PlayerLevelChangeEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1level_1_1_player_level_change_event.html", null ],
      [ "PlayerLevelUpEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1level_1_1_player_level_up_event.html", null ],
      [ "PlayerAddMaxXpEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_add_max_xp_event.html", null ],
      [ "PlayerMaxXpChangeEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1max_1_1_player_max_xp_change_event.html", null ],
      [ "PlayerAddXpEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_add_xp_event.html", null ],
      [ "PlayerXpChangeEvent", "class_inko_h_x_1_1_leve_library_1_1event_1_1xp_1_1_player_xp_change_event.html", null ]
    ] ]
];