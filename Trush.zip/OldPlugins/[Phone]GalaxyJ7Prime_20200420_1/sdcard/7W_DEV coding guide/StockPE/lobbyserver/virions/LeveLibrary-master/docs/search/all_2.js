var searchData=
[
  ['datafile',['DataFile',['../class_inko_h_x_1_1_leve_library_1_1_data_file.html',1,'InkoHX::LeveLibrary']]],
  ['datafile_2ephp',['DataFile.php',['../_data_file_8php.html',1,'']]]
];
