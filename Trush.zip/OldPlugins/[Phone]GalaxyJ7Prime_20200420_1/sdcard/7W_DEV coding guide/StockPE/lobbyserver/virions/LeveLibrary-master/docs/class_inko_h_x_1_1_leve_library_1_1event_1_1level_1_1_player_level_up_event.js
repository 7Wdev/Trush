var class_inko_h_x_1_1_leve_library_1_1event_1_1level_1_1_player_level_up_event =
[
    [ "__construct", "class_inko_h_x_1_1_leve_library_1_1event_1_1level_1_1_player_level_up_event.html#a2d8fda9b36a8cef22311ea32fd93c6bf", null ],
    [ "getNewLevel", "class_inko_h_x_1_1_leve_library_1_1event_1_1level_1_1_player_level_up_event.html#ab2403260576125dc705dabf079f1adbb", null ],
    [ "getOldLevel", "class_inko_h_x_1_1_leve_library_1_1event_1_1level_1_1_player_level_up_event.html#ac57c85a8d339d5f726dd1e2b59c1cad0", null ],
    [ "setNewLevel", "class_inko_h_x_1_1_leve_library_1_1event_1_1level_1_1_player_level_up_event.html#a1902daa678a88e51b4f2cdfd90c0aa42", null ]
];