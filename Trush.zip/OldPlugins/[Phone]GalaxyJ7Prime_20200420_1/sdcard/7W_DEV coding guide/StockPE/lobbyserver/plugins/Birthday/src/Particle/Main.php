<?php
/*
  _____  __    __      _              
 |___  |/ / /\ \ \  __| |  ___ __   __
    / / \ \/  \/ / / _` | / _ \\ \ / /
   / /   \  /\  / | (_| ||  __/ \ V / 
  /_/     \/  \/   \__,_| \___|  \_/  
                                      
                                      */
namespace Particle;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;

use pocketmine\level\particle\DustParticle;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\scheduler\Task as PluginTask;
use pocketmine\utils\TextFormat;
use pocketmine\math\Vector3;

class Main extends PluginBase implements Listener{
	
	public $players = [];
    public $particle1 = array("BirthdayParticles");
    public $name = array();
	
	public function onEnable()
	{
		$this->getLogger()->info("[Enabled] by 7Wdev");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getScheduler()->scheduleRepeatingTask(new Particle($this), 5);
	}
	
	public function onCommand(CommandSender $player, Command $command, string $label, array $params) : bool
	{
	$name = $player->getName();
	$level = $player->getLevel();
		if(!$player instanceof Player){
			$player->sendMessage("Use the command ingame");
			return false;
		}
		$username = strtolower($player->getName());
		if($command->getName() == "birthday"){
			if(!in_array($name, $this->particle1)) {
				
			    $this->particle1[] = $name;
			    $player->sendMessage("§l§7[ §6StockPE §7] §r§a enjoy your birthday the particles enabled!");
			
		    } else {
			    
			    unset($this->particle1[array_search($name, $this->particle1)]);
				$player->sendMessage("§l§7[ §6StockPE §7] §r§a enjoy your birthday the particles disabled!");
			}
		return true;
	}
}
}

class Particle extends PluginTask {
	
	public function __construct($plugin) {
		$this->plugin = $plugin;
	}

	public function onRun($tick) {
		
		foreach($this->plugin->getServer()->getOnlinePlayers() as $player) {
			$name = $player->getName();
			$inv = $player->getInventory();
			
			$players = $player->getLevel()->getPlayers();
			$level = $player->getLevel();
			
			$x = $player->getX();
			$y = $player->getY() + 1;
			$z = $player->getZ();
			
			if(in_array($name, $this->plugin->particle1)) {
				
				$r = 40;
				$g = 175;
				$b = 216;
				
				$center = new Vector3($x, $y, $z);
				$particle = new DustParticle($center, $r, $g, $b, 1);
				$particle2 = new DustParticle($center, 197, 38, 215, 1);
				
				for($yaw = 0; $yaw <= 20; $yaw += (M_PI * 5) / 15){
					$x = -sin($yaw) + $center->x;
					$z = cos($yaw) + $center->z;
					$y = $center->y;
					
					$particle2->setComponents($x, $y, $z);
					$particle->setComponents($x, $y, $z);
					$level->addParticle($particle);
					$level->addParticle($particle2);
					
						
				}
		    }
			
		    }
		
	    }
}