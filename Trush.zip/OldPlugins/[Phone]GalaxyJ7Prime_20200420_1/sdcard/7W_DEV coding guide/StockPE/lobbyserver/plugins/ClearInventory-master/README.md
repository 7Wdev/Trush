# [![BlazeTheDev](https://i.imgur.com/fgVMXSe.png?1)]()

## License
| License |
| :---: |
| [![BlazinVanish License](https://img.shields.io/github/license/iiFlamiinBlaze/ClearInventory.svg?label=License)](LICENSE) |

Make sure to read all of the license as it could change at anytime.

## Information
| Download | View Count | Discord |
| :---: | :---: | :---: |
 [![Download](https://img.shields.io/badge/download-latest-blue.svg)](https://poggit.pmmp.io/ci/iiFlamiinBlaze/ClearInventory/) | [![View Count](http://hits.dwyl.io/iiFlamiinBlaze/ClearInventory.svg)](http://hits.dwyl.io/iiFlamiinBlaze/ClearInventory) | <a href="https://discord.gg/znEsFsG"><img src="https://discordapp.com/api/guilds/425712766687510528/embed.png" alt="Discord server"/></a> |
 
This plugin allows you to clear a players inventory through configs. This plugin is for anyone to use.
If you have any issues with the plugin, please make an issue [here](https://github.com/iiFlamiinBlaze/ClearInventory/issues/new).
* Credits: [BlazeTheDev](https://github.com/iiFlamiinBlaze)

## How to use
For more info about how to use the plugin go to the [ClearInventory Wiki](https://iiflamiinblaze.github.io/projects/clearinventory/).