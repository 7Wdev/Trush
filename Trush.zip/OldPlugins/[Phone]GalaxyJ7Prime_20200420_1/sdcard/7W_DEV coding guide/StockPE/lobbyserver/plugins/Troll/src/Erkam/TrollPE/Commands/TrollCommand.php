<?php

namespace Erkam\TrollPE\Commands;

use Erkam\TrollPE\TrollPE;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\network\mcpe\protocol\types\CommandEnum;
use pocketmine\network\mcpe\protocol\types\CommandParameter;
use pocketmine\Player;

class TrollCommand extends PluginCommand {

    public function __construct(TrollPE $plugin){
        parent::__construct("troll", $plugin);
        $this->setPermission("trollpe.command");
        if(TrollPE::getInstance()->getServer()->getName() === "Altay"){
            $params = ["chat", "rocket", "freeze", "trigger", "explode", "fakeop", "su"];
            $this->setParameters([
                new CommandParameter("arguments", CommandParameter::ARG_TYPE_STRING, false, new CommandEnum("args", $params)),
                new CommandParameter("player", CommandParameter::ARG_TYPE_TARGET, false)
            ]);
        }
        $this->setDescription("TrollPE Command.");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if($sender instanceof Player && $sender->hasPermission("trollpe.command")){
            if(isset($args[0])){
                switch(strtolower($args[0])){
                    case "chat":
                        $pname = $args[1];
                        if(!empty($pname)){
                            $player = TrollPE::getInstance()->getServer()->getPlayer($pname);
                            if($player != null){
                                if(isset($args[2])){
                                    unset($args[0], $args[1]);
                                    $msg = implode(" ", $args);
                                    if(!empty($msg)){
                                        $player->chat($msg);
                                    }
                                } else{
                                    $sender->sendMessage(TrollPE::PREFIX."§7Du hast die Nachricht vergessen.");
                                }
                            } else{
                                $sender->sendMessage(TrollPE::PREFIX."§cSpieler wurde nicht Gefunden.");
                            }
                        }
                        break;
                    case "rocket":
                        $pname = $args[1];
                        if(!empty($pname)){
                            $player = TrollPE::getInstance()->getServer()->getPlayer($pname);
                            if($player != null){
                                $multipler = intval($args[2]);
                                if(isset($args[2]) && is_int($multipler)){
                                    TrollPE::getInstance()->rocket($player, $multipler);
                                } else{
                                    TrollPE::getInstance()->rocket($player);
                                }
                                $sender->sendMessage(TrollPE::PREFIX."§c".$player->getName()." §fist jetzt in eine Rakete.");
                            } else{
                                $sender->sendMessage(TrollPE::PREFIX."§cSpieler wurde nicht Gefunden.");
                            }
                        }
                        break;
                    case "freeze":
                        $pname = $args[1];
                        if(!empty($pname)){
                            $player = TrollPE::getInstance()->getServer()->getPlayer($pname);
                            if($player != null){
                                if(!in_array($player->getName(), TrollPE::$FREZZED)){
                                    TrollPE::$FREZZED[] = $player->getName();
                                    $player->setImmobile(true);
                                    $sender->sendMessage(TrollPE::PREFIX."§fDu bist Eingefroren §a".$player->getName());
                                } else{
                                    unset(TrollPE::$FREZZED[array_search($player->getName(), TrollPE::$FREZZED)]);
                                    $player->setImmobile(false);
                                    $sender->sendMessage(TrollPE::PREFIX."§cDu bist wieder Aufgetaut §a".$player->getName());
                                }
                            } else{
                                $sender->sendMessage(TrollPE::PREFIX."§cSpieler wurde nicht Gefunden.");
                            }
                        }
                        break;
                    case "trigger":
                        $pname = $args[1];
                        if(!empty($pname)){
                            $player = TrollPE::getInstance()->getServer()->getPlayer($pname);
                            if($player != null){
                                if(!in_array($player->getName(), TrollPE::$TRIGERRED)){
                                    TrollPE::$TRIGERRED[] = $player->getName();
                                    $sender->sendMessage(TrollPE::PREFIX."§fDu bist jetzt Getriggert §b".$player->getName());
                                } else{
                                    unset(TrollPE::$TRIGERRED[array_search($player->getName(), TrollPE::$TRIGERRED)]);
                                    $sender->sendMessage(TrollPE::PREFIX."§cDu bist nicht mehr Getriggert §b".$player->getName());
                                }
                            } else{
                                $sender->sendMessage(TrollPE::PREFIX."§cSpieler wurde nicht Gefunden.");
                            }
                        }
                        break;
                    case "explode":
                        $pname = $args[1];
                        if(!empty($pname)){
                            $player = TrollPE::getInstance()->getServer()->getPlayer($pname);
                            if($player !== null){
                                $radius = intval($args[2]);
                                if(isset($args[2]) && is_int($radius)){
                                    TrollPE::getInstance()->blowup($player->getPosition(), $radius);
                                } else{
                                    TrollPE::getInstance()->blowup($player->getPosition());
                                }
                                $sender->sendMessage(TrollPE::PREFIX."§eGesprengt §c".$player->getName());
                            } else{
                                $sender->sendMessage(TrollPE::PREFIX."§cSpieler wurde nicht Gefunden.");
                            }
                        }
                        break;
                    case "fakeop":
                        $pname = $args[1];
                        if(!empty($pname)){
                            $player = TrollPE::getInstance()->getServer()->getPlayer($pname);
                            if($player !== null){
                                $sender->sendMessage(TrollPE::PREFIX."Du Hast  fakeop Aktiviert bei ".$player->getName());
                                $player->sendMessage("§7You are now op!");
                            } else{
                                $sender->sendMessage(TrollPE::PREFIX."§cSpieler wurde nicht Gefunden.");
                            }
                        }
                        break;
                    case "su":
                        $pname = $args[1];
                        if(!empty($pname)){
                            $player = TrollPE::getInstance()->getServer()->getPlayer($pname);
                            if($player !== null){
                                unset($args[0], $args[1]);
                                $cmd = implode(" ", $args);
                                TrollPE::getInstance()->getServer()->dispatchCommand($player, $cmd, true);
                                $sender->sendMessage(TrollPE::PREFIX."§7Command ausführen für §a".$player->getName()."§8: §r".$cmd);
                            } else{
                                $sender->sendMessage(TrollPE::PREFIX."§cSpieler wurde nicht Gefunden.");
                            }
                        }
                        break;
                    default:
                        $this->sendHelp($sender);
                        break;
                }
            } else{
                $this->sendHelp($sender);
            }
        }
    }

    private function sendHelp(Player $player){
        $player->sendMessage("§7-----------§4Troll§7-----------
§f»§e /troll chat [Name] [Nachricht]§7 Schreibe für jemanden anderen.
§f»§e /troll rocket [Name] [Anzahl]§7 Schieße jemanden in die Luft.
§f»§e /troll freeze [Name]§7 Lässt einen Spieler Einfrieren.
§f»§e /troll explode [Name] [Anzahl]§7 Lässt einen Spieler Explodieren.
§f»§e /troll trigger [Name]§7 Triggere einen Spieler.
§f»§e /troll su [Name] [Befehl]§7 Lässt jeden Befehl zu! Aber so das es niemand sieht was du Eingibst.
§f»§e /troll fakeop [Name]§7 Lässt einem Spieler anzeigen das er OP hätte, obwohl er es nicht hat.
---------------------------
");
    }
}