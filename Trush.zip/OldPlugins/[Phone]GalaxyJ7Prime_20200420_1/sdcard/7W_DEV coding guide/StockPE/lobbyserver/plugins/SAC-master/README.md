# SAC (ShadowAntiCheat) [![](https://poggit.pmmp.io/shield.state/ShadowAntiCheat)](https://poggit.pmmp.io/p/ShadowAntiCheat) [![](https://poggit.pmmp.io/ci.shield/DarkWav/SAC/ShadowAntiCheat)](https://poggit.pmmp.io/ci/DarkWav/SAC/ShadowAntiCheat) [![](https://img.shields.io/github/license/DarkWav/SAC.svg?label=License)](https://github.com/DarkWav/SAC/blob/master/LICENSE)

### A powerfull AntiCheat software made to detect unfair gamplay advantages.

## Current Release: 3.6.5<br>Supported PMMP-API Versions: 3.X.X

## An AntiCheat plugin for [PocketMine-MP](https://github.com/pmmp/pocketmine-mp) and [Altay](https://github.com/TuranicTeam/Altay).<br>Compatible with MCPE 1.X.X.

## Find The Wiki and Phar Downloads [Here](https://github.com/DarkWav/ShadowAntiCheat/wiki).<br>[FAQ](https://github.com/DarkWav/SAC/wiki/FAQ)

## For Developers: [Developer API](https://github.com/DarkWav/SAC/wiki/Developer-API)

## [Issues / Help / Support / Bug Report](https://github.com/DarkWav/SAC/issues)

# Features:<br>
## - AntiKillAura<br>- AntiReach<br>- AntiFly<br>- AntiSpider (W.I.P)<br>- AntiSpeed<br>- AntiGlide<br>- AntiNoClip (BETA)<br>- AntiRegen<br>- AntiFastClick<br>- AntiFastBow<br>- AutoBanSytem<br>  Read more about Block Hacks [Here](https://github.com/DarkWav/SAC/wiki/About-Block-Hack-Detection).

## Requirements:
### - Latest PocketMine-MP release (forks and dev builds might work, but not guaranteed)
### - Especially important: Very high Computing Power
### - At least 4GB of RAM
### - PHP 7.2 or higher

### Read the [License](https://github.com/DarkWav/ShadowAntiCheat/blob/master/LICENSE) before downloading this Software.
### By downloading this Software you AGREE to the [License](https://github.com/DarkWav/ShadowAntiCheat/blob/master/LICENSE)!
### Article 13 information: This Project is still strongly copyleft according to the GPLv3. Therefore, you needn't pay ANY KIND of licension fee when using/liniking/distributing this material, meaning Articel 11 & 17 of the EU Copyright Law DO NOT APPLY TO THIS PARTICULAR PROJECT IN ANY WAY. Feel free to use it just like before!
