<?php

namespace Erkam\TrollPE;

use Erkam\TrollPE\Tasks\TriggerTask;
use Erkam\TrollPE\Commands\TrollCommand;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\level\Explosion;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class TrollPE extends PluginBase implements Listener {

    /** @var TrollPE $instance */
    public static $instance;

    public static $FREZZED = [];
    public static $TRIGERRED = [];

    public const PREFIX = "§6Troll §8»§r ";

    public function onEnable(){
        self::$instance = $this;
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getCommandMap()->register("TrollPE", new TrollCommand($this));
        $this->getScheduler()->scheduleRepeatingTask(new TriggerTask(), 30);
    }

    public static function getInstance(): TrollPE{
        return self::$instance;
    }

    public function rocket(Player $player, int $power = 1){
        $player->setMotion(new Vector3(0, $power, 0));
    }

    public function blowup(Position $pos, int $radius = 1){
        $eplode = new Explosion($pos, $radius);
        $eplode->explodeB();
    }

    public function onQuit(PlayerQuitEvent $event){
        $player = $event->getPlayer();
        $name = $player->getName();
        if(in_array($name, TrollPE::$FREZZED)){
            unset(TrollPE::$FREZZED[array_search($name, TrollPE::$FREZZED)]);
        }
        if(in_array($name, TrollPE::$TRIGERRED)){
            unset(TrollPE::$TRIGERRED[array_search($name, TrollPE::$TRIGERRED)]);
        }
    }
}