<?php
//7.3.2019                   shari7             7Wdev

namespace com\Joker7W;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class MainClass extends PluginBase implements Listener {

	   public function onEnable(){
	        $this->getServer()->getPluginManager()->registerEvents($this, $this);
	        $this->getLogger()->info(TextFormat::GREEN . "plugin works by 7awari");
	   }
    
    
    public function onPlayerJoin(PlayerJoinEvent $e){
	  			    $p = $e->getPlayer();
					    $e->setJoinMessage("");
					    $p->sendMessage(TextFormat::YELLOW . "Welcome To Our Server!");
				  	   $p->sendMessage(TextFormat::AQUA . "Server By 7awariGamer!");
				  	   $p->sendMessage(TextFormat::GOLD . "Plz Like + Subscribe + Share!");
			}
    
	   	public function onDisable(){
  	    	   $this->getLogger()->info(TextFormat::DARK_RED . "error");
	  	}

}
?>