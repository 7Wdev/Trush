<?php

#=========================================================================================================================#

namespace SpiderUI;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;

#=========================================================================================================================#

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;

#=========================================================================================================================#

use pocketmine\event\player\PlayerQuitEvent;

#=========================================================================================================================#

use SpiderUI\FormEvent\Form;
use SpiderUI\FormEvent\SimpleForm;

#=========================================================================================================================#


class Main extends PluginBase implements Listener
{

#=========================================================================================================================#

    public $formCount = 0;
    public $forms = [];

#=========================================================================================================================#

    public function onEnable() : void {
     $this->getLogger()->info("Plugin SpiderUI Buatan MCCreeperYT");
     $this->formCount = rand(0, 0xFFFFFFFF);
     $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

#=========================================================================================================================#

    public function createSimpleForm(callable $function = null) : SimpleForm {
     $this->formCountBump();
     $form = new SimpleForm($this->formCount, $function);
     $this->forms[$this->formCount] = $form;
     return $form;
    }

#=========================================================================================================================#

    public function formCountBump() : void {
     ++$this->formCount;
     if($this->formCount & (1 << 32)){
      $this->formCount = rand(0, 0xFFFFFFFF);
     }
  }

#=========================================================================================================================#

    public function onPacketReceived(DataPacketReceiveEvent $ev) : void {
     $pk = $ev->getPacket();
     if($pk instanceof ModalFormResponsePacket){
      $player = $ev->getPlayer();
      $formId = $pk->formId;
      $data = json_decode($pk->formData, true);
      if(isset($this->forms[$formId])){
       $form = $this->forms[$formId];
       if(!$form->isRecipient($player)){
        return;
       }
       $callable = $form->getCallable();
       if(!is_array($data)){
        $data = [$data];
       }
       if($callable !== null) {
        $callable($ev->getPlayer(), $data);
       }
       unset($this->forms[$formId]);
       $ev->setCancelled();
       }
    }
 }

#=========================================================================================================================#

    public function onPlayerQuit(PlayerQuitEvent $ev) {
     $player = $ev->getPlayer();
     foreach ($this->forms as $id => $form) {
      if($form->isRecipient($player)) {
       unset($this->forms[$id]);
       break;
      }
   }
}

#=========================================================================================================================#

    public function SpiderMenu($player): void{
     $form = $this->createSimpleForm(function (Player $player, array $data) {
     if (isset($data[0])){
      $scat = $data[0];
       switch ($scat) {
        case 0:
         $player->setCanClimbWalls(true);
         $player->sendMessage("§f§l[§r§eSpiderUI§r§f§l]§r§6§o Mode Spider Anda Berhasil Di Aktifkan§r§f.");
        break;
        return true;
        case 1:
         $player->setCanClimbWalls(false);
         $player->sendMessage("§f§l[§r§eSpiderUI§r§f§l]§r§6§o Mode Spider Anda Berhasil Di Nonaktifkan§r§f.");
        break;
        return true;
        case 2:
        break;
        return true;
       }
    } 
 });
 $form->setTitle("§r§f§l-=§eSpider Menu§r§l§f=-");
 $form->setContent("§6§oSilahkan Pilih On Atau Off Mode Spider§r§f!");
 $form->addButton("§0ON");
 $form->addButton("§0OFF");
 $form->addButton("§0CLOSE");
 $form->sendToPlayer($player);
 }

#=========================================================================================================================#

    public function onCommand(CommandSender $player, Command $command, string $label, array $args): bool{ 
     switch($command->getName()){
      case "spider";
       if($player instanceof Player){
        if($player->hasPermission("spiderui.spider")){
         $this->SpiderMenu($player);
        }
     }
     break;
     }
     return true;
     }
  }

#=========================================================================================================================#