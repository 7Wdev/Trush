<?php
namespace com\MCBE;

//pmmp libs!
use pocketmine\command\PluginIdentifiableCommand;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\utils\CommandException;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\server\ServerCommandEvent;
use pocketmine\plugin\Plugin;
use pocketmine\utils\TextFormat as C;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\player\PlayerQuitEvent as Disconnect;
use pocketmine\scheduler\Task;
use pocketmine\scheduler\TaskScheduler;

//mine libs!
use com\MCBE\StandardScoreboard;
use com\MCBE\Main;
use com\MCBE\MTask;

class MCommand extends Command implements PluginIdentifiableCommand {

    private $command;
    
    private $plugin;
    
    private $task;

    public function __construct(Main $plugin)
      {
         $cmd = Main::$cfg->get('cmd');
         parent::__construct($cmd, "displays pvp hud!", "/" . $cmd, []);
         $this->setPermission("pvphud.command");
         $this->command = $plugin;
         $this->plugin = $plugin;
      }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
      {
         if($sender instanceof Player)
          {
             $task = new MTask($sender);
             $this->task = $task;
             $this->plugin->getScheduler()->scheduleRepeatingTask($task, 30);
          } else
              {
                 //nothing ...
              }
      }
    
    public function onDisconnect(Disconnect $e)
      {
         $player = $e->getPlayer();
         $task->getHandler()->cancel();
         if(StandardScoreboard::hasScore($player) === true)
          {
             StandardScoreboard::removeScore($player);
          }
      }
    
    public function getPlugin(): Plugin
      {
         return $this->plugin;
      }
}
?>