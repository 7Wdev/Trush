<?php
declare(strict_types=1);
namespace com\MCBE;

//pmmp libs!
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\server\ServerCommandEvent;
use pocketmine\utils\TextFormat as C;
use pocketmine\command\{Command, CommandSender, defaults\VanillaCommand};
use pocketmine\command\CommandMap;
use pocketmine\utils\Config;
use pocketmine\scheduler\Task;
use pocketmine\scheduler\TaskScheduler;
use pocketmine\inventory\Inventory;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\Item;

//mine libs!
use com\MCBE\StandardScoreboard;
use com\MCBE\MCommand;
use com\MCBE\Main;

class MTask extends Task implements Listener {
    
    public function __construct($sender)
      {
         $this->sender = $sender;
      }
      
    public function onRun(int $currentTick)
      {
         $sender = $this->sender;
         $title = Main::$cfg->get('title');
         $extratext = Main::$cfg->get('extratext');
         $health = Main::$cfg->get('health');
         $phealth = Main::playerHealth($sender);
         $helmet = Main::$cfg->get('helmet');
         $phelmet = Main::helmetHealth($sender);
         $chestplate = Main::$cfg->get('chestplate');
         $pchestplate = Main::chestplateHealth($sender);
         $leggings = Main::$cfg->get('leggings');
         $pleggings = Main::leggingsHealth($sender);
         $boots = Main::$cfg->get('boots');
         $pboots = Main::bootstHealth($sender);
         $combat = Main::$cfg->get('combat');
         $pcombat = Main::combatLog($sender);
         StandardScoreboard::setScore($sender, $title);
         StandardScoreboard::setScoreLine($sender, 1, $extratext);
         StandardScoreboard::setScoreLine($sender, 2, $health . $phealth . "/100");
         StandardScoreboard::setScoreLine($sender, 3, "\n");
         StandardScoreboard::setScoreLine($sender, 4, "   ");
         StandardScoreboard::setScoreLine($sender, 5, $helmet . $phelmet . "/100");
         StandardScoreboard::setScoreLine($sender, 6, $chestplate . $pchestplate . "/100");
         StandardScoreboard::setScoreLine($sender, 7, $leggings . $pleggings . "/100");
         StandardScoreboard::setScoreLine($sender, 8, $boots . $pboots . "/100");
         StandardScoreboard::setScoreLine($sender, 9, "\n");
         StandardScoreboard::setScoreLine($sender, 10, $combat . $pcombat . "s left");
      }
}
?>