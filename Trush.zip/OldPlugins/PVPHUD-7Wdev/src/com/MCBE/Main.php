<?php
declare(strict_types=1);
namespace com\MCBE;

//pmmp libs!
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\item\Durable;
use pocketmine\Server;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\server\ServerCommandEvent;
use pocketmine\utils\TextFormat as C;
use pocketmine\command\{Command, CommandSender, defaults\VanillaCommand};
use pocketmine\command\CommandMap;
use pocketmine\inventory\ArmorInventory;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\utils\Config;

//mine libs!
use com\MCBE\StandardScoreboard;
use com\MCBE\MCommand;
use com\MCBE\MTask;

class Main extends PluginBase implements Listener {
    
    public static $cfg;
    
    private static $time;
    
    public function onEnable(): void
      {
         $this->getServer()->getPluginManager()->registerEvents($this, $this);
         $this->getServer()->getLogger()->info("Enabled By 7Wdev");
         
         //config setup!
         @mkdir($this->getDataFolder());
         $this->saveDefaultConfig();
         $this->saveResource("editme.yml");
         self::$cfg = new Config($this->getDataFolder() . "editme.yml", Config::YAML);
         
         //cmd register!
         $cmd = self::$cfg->get('cmd');
         $this->getServer()->getCommandMap()->register($cmd, new MCommand($this));
      }
      
    public static function playerHealth($player): float
      {
         $min = $player->getHealth();
         $max = $player->getMaxHealth();
         $health = ($min / $max) * 100;
         return $health;
      }
    
    public static function leggingsHealth($player)
      {
         if($player instanceof Player and !$player->isClosed())
          {
             $getleggings = $player->getArmorInventory()->getLeggings();
             if($getleggings instanceof Durable)
              {
                 $damage = $player->getArmorInventory()->getLeggings()->getDamage();
                 $maxd = $player->getArmorInventory()->getLeggings()->getMaxDurability();
                 $l = (($maxd - $damage) / $maxd) * 100;
                 return number_format($l, 1);
              } else
                  {
                     return "not found";
                  }
          }
      }
    
    public static function chestplateHealth($player)
      {
         if($player instanceof Player and !$player->isClosed())
          {
             $getchestplate = $player->getArmorInventory()->getChestplate();
             if($getchestplate instanceof Durable)
              {
                 $damage = $player->getArmorInventory()->getChestplate()->getDamage();
                 $maxd = $player->getArmorInventory()->getChestplate()->getMaxDurability();
                 $c = (($maxd - $damage) / $maxd) * 100;
                 return number_format($c, 1);
              } else
                  {
                     return "not found";
                  }
           }
      }
    
    public static function bootstHealth($player)
      {
         if($player instanceof Player and !$player->isClosed())
          {
             $getboots = $player->getArmorInventory()->getBoots();
             if($getboots instanceof Durable)
              {
                 $damage = $player->getArmorInventory()->getBoots()->getDamage();
                 $maxd = $player->getArmorInventory()->getBoots()->getMaxDurability();
                 $b = (($maxd - $damage) / $maxd) * 100;
                 return number_format($b, 1);
              } else
                  {
                     return "not found";
                  }
          }
      }
    
    public static function helmetHealth($player)
      {
         if($player instanceof Player and !$player->isClosed())
          {
             $gethelmet = $player->getArmorInventory()->getHelmet();
             if($gethelmet instanceof Durable)
              {
                 $damage = $player->getArmorInventory()->getHelmet()->getDamage();
                 $maxd = $player->getArmorInventory()->getHelmet()->getMaxDurability();
                 $h = (($maxd - $damage) / $maxd) * 100;
                 return number_format($h, 1);
              } else
                  {
                     return "not found";
                  }
          }
      }
    
    public static function combatLog($player)
      {
         if($player->getHealth() < $player->getMaxHealth())
          {
             self::$time = 0;
          } else
              {
                 self::$time++;
              }
         return self::$time;
      }
}
?>